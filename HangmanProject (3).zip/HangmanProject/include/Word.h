#pragma once
#include <string>
#include <vector>

class Word {
public:
    std::string actualWord;
    std::string guessedWord;
    std::vector<char> usedLetters;

    Word();

    void chooseRandomWord();
    bool checkGuess(char letter);
    bool isComplete() const;
    void reset();
    void reset(const std::string& w);   
};
