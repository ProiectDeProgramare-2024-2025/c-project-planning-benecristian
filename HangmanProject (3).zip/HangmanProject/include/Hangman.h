#pragma once
#include "Word.h"

class Hangman {
public:
    int lives;
    int maxLives;
    Word word;

    Hangman(int maxLives = 6) : maxLives(maxLives), lives(maxLives) {}

    void reset(const std::string& newWord);
    bool guessLetter(char letter);
    bool isGameOver() const;
    bool isWin() const;

    void saveGameState(const std::string& filename);
    bool loadGameState(const std::string& filename);
};
