#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <algorithm>

#define COLOR_RESET   "\033[0m"
#define COLOR_GREEN   "\033[32m"
#define COLOR_RED     "\033[31m"
#define COLOR_YELLOW  "\033[33m"
#define COLOR_LIGHT_BLUE "\033[38;5;117m"
#define COLOR_VIOLET "\033[35m"

struct GameState {
    std::string actualWord;
    std::string guessedWord;
    int lives;
    std::vector<char> usedLetters;
};

bool loadGameState(GameState& gs) {
    std::ifstream file("game_state.txt");
    if (!file) return false;

    std::getline(file, gs.actualWord);
    std::getline(file, gs.guessedWord);
    file >> gs.lives;

    gs.usedLetters.clear();
    char c;
    while (file >> c) {
        gs.usedLetters.push_back(c);
    }

    return true;
}

void printHangman(int lives) {
    int stage = 6 - lives;
    const std::vector<std::string> stages = {
        "  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========\n",
        "  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========\n"
    };
    stage = std::clamp(stage, 0, 6);
    std::cout << stages[stage];
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << COLOR_LIGHT_BLUE << "Usage: hangman_ui.exe <command> [args]\n\n" << COLOR_RESET;
        std::cout << COLOR_VIOLET << "Available commands:\n" << COLOR_RESET;
        std::cout << COLOR_GREEN << "  start              - Start a new game\n" << COLOR_RESET;
        std::cout << COLOR_GREEN <<"  restart            - Reset the game state\n" << COLOR_RESET;
        std::cout << COLOR_GREEN <<"  guess <letter>     - Guess a letter\n" << COLOR_RESET;
        std::cout << COLOR_GREEN <<"  view_state         - View current game status\n" << COLOR_RESET;
        std::cout << "\nNext step: run hangman_logic.exe to choose/check the word.\n" << COLOR_RESET;
        return 0;
    }


    std::string cmd = argv[1];

    if (cmd == "start") {
        std::cout << COLOR_GREEN << "New game started." << COLOR_RESET << " The other player must now choose a word.\n";
    }
    else if (cmd == "restart") {
        std::ofstream ofs("game_state.txt", std::ofstream::trunc);
        ofs.close();
        std::cout << COLOR_LIGHT_BLUE << "Game restarted. The other player must now choose a new word.\n" << COLOR_RESET;
    }
    else if (cmd == "guess") {
    if (argc < 3) {
        std::cerr << "Please specify a letter to guess\n";
        return 1;
    }

    char letter = tolower(argv[2][0]);
    GameState gs;
    if (!loadGameState(gs)) {
        std::cerr << "Failed to load game state.\n";
        return 1;
    }

    if (gs.lives <= 0) {
        std::cout << COLOR_RED << "Game over! The word was: " << gs.actualWord << COLOR_RESET << "\n";
        return 0;
    }

    if (gs.guessedWord == gs.actualWord) {
        std::cout << COLOR_GREEN << "You already won! The word was: " << gs.actualWord << COLOR_RESET << "\n";
        return 0;
    }

    if (std::find(gs.usedLetters.begin(), gs.usedLetters.end(), letter) != gs.usedLetters.end()) {
        std::cout << COLOR_YELLOW << "You already used the letter '" << letter << "'. Try a different one." << COLOR_RESET << "\n";
        return 0;
    }


    std::ofstream file("game_state.txt");
    file << gs.actualWord << "\n" << gs.guessedWord << "\n" << gs.lives << "\n";
    for (char c : gs.usedLetters) file << c << " ";
    file << "\n";
    file.close();

    std::cout << "Letter '" << letter << "' added. Now run ";
    std::cout << COLOR_YELLOW << "./hangman_logic.exe check_guess " << letter << COLOR_RESET << " to evaluate.\n";
    }

    else if (cmd == "view_state") {
        GameState gs;
        if (!loadGameState(gs)) {
            std::cerr << "No saved game found\n";
            return 1;
        }

        printHangman(gs.lives);
        std::cout << "Word: " << gs.guessedWord << "\n";
        std::cout << "Lives left: " << gs.lives << "\n";
        std::cout << "Used letters: ";
        for (char c : gs.usedLetters) std::cout << c << " ";
        std::cout << "\n";

        if (gs.guessedWord == gs.actualWord) {
            std::cout << COLOR_GREEN << "You won! The word was: " << gs.actualWord << COLOR_RESET << "\n";
        } else if (gs.lives <= 0) {
            std::cout << COLOR_RED << "Game over! The word was: " << gs.actualWord << COLOR_RESET << "\n";
        }
    }
    else {
        std::cerr << "Unknown command\n";
        return 1;
    }

    return 0;
}
