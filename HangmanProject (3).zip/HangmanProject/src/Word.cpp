#include "Word.h"
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <cctype>

Word::Word() {
    guessedWord = "";
    actualWord = "";
    usedLetters.clear();
}

bool Word::checkGuess(char letter) {
    letter = std::tolower(letter);

    // Already used?
    if (std::find(usedLetters.begin(), usedLetters.end(), letter) != usedLetters.end()) {
        return false; // Already guessed this letter
    }

    usedLetters.push_back(letter);

    bool found = false;
    for (size_t i = 0; i < actualWord.size(); ++i) {
        if (std::tolower(actualWord[i]) == letter) {
            guessedWord[i] = actualWord[i]; // Preserve original case
            found = true;
        }
    }

    return found;
}

bool Word::isComplete() const {
    return guessedWord == actualWord;
}

void Word::reset() {
    actualWord = "";
    guessedWord = "";
    usedLetters.clear();
}

void Word::reset(const std::string& w) {
    actualWord = w;
    guessedWord = std::string(w.length(), '_');
    usedLetters.clear();
}
