#include "Hangman.h"
#include <fstream>
#include <algorithm>
#include <limits> // At the top of the file

void Hangman::reset(const std::string& newWord) {
    lives = maxLives;
    word.reset(newWord);
}

bool Hangman::guessLetter(char letter) {
    // Normalize letter to lowercase
    letter = tolower(letter);

    // If letter already used, do nothing and return false
    if (std::find(word.usedLetters.begin(), word.usedLetters.end(), letter) != word.usedLetters.end())
        return false;

    word.usedLetters.push_back(letter);

    bool found = false;
    for (size_t i = 0; i < word.actualWord.size(); ++i) {
        if (tolower(word.actualWord[i]) == letter) {
            word.guessedWord[i] = word.actualWord[i]; // Keep original case
            found = true;
        }
    }
    if (!found) {
        --lives;
    }
    return found;
}

bool Hangman::isGameOver() const {
    return lives <= 0 || word.isComplete();
}

bool Hangman::isWin() const {
    return word.isComplete();
}

void Hangman::saveGameState(const std::string& filename) {
    std::ofstream file(filename);
    if (!file) return;
    file << word.actualWord << "\n";
    file << word.guessedWord << "\n";
    file << lives << "\n";
    for (char c : word.usedLetters) {
        file << c << " ";
    }
    file << "\n";
}



bool Hangman::loadGameState(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) return false;

    std::getline(file, word.actualWord);
    std::getline(file, word.guessedWord);
    file >> lives;
    file.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 

    word.usedLetters.clear();
    char c;
    while (file >> c) {
        word.usedLetters.push_back(c);
    }

    return true;
}

