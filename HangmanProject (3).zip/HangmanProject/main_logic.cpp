#include "Hangman.h"
#include <iostream>
#include <string>
#include <algorithm>

#define COLOR_RESET   "\033[0m"
#define COLOR_GREEN   "\033[32m"
#define COLOR_RED     "\033[31m"
#define COLOR_VIOLET "\033[35m"
#define COLOR_LIGHT_BLUE "\033[38;5;117m"



#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#endif

std::string getHiddenInput() {
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode = 0;
    GetConsoleMode(hStdin, &mode);
    SetConsoleMode(hStdin, mode & (~ENABLE_ECHO_INPUT));

    std::string input;
    std::getline(std::cin, input);

    SetConsoleMode(hStdin, mode);
    std::cout << std::endl;
    return input;

}

int main(int argc, char* argv[]) {
    Hangman game;
    const std::string stateFile = "game_state.txt";

    if (argc < 2) {
        std::cout << COLOR_LIGHT_BLUE << "Usage: hangman_logic.exe <command> [args]\n\n"<< COLOR_RESET;
        std::cout << COLOR_VIOLET <<  "Available commands:"<< COLOR_RESET << "\n";
        std::cout << COLOR_GREEN << "  choose_word <word>        - Choose the word to be guessed (shows in history)" << COLOR_RESET << "\n";
        std::cout << COLOR_GREEN << "  choose_word               - Input word hidden (recommended)" << COLOR_RESET << "\n";
        std::cout << COLOR_GREEN << "  choose_random_word        - Choose a random word from words.txt" << COLOR_RESET << "\n";
        std::cout << COLOR_GREEN << "  check_guess <letter>      - Evaluate the guessed letter" << COLOR_RESET << "\n";
        return 0;
    }


    std::string cmd = argv[1];

    if (cmd == "choose_word") {
    std::string word;
    if (argc >= 3) {
        std::cerr << "Warning: typing word as argument will show it in the terminal history.\n";
        std::cerr << "For security, run without arguments and input word when prompted.\n";
        return 1;
    }
    else {
        std::cout << "Enter the word to guess (input hidden): ";
        word = getHiddenInput();
        std::transform(word.begin(), word.end(), word.begin(), ::tolower);
    }

    game.reset(word);
    game.saveGameState(stateFile);
    std::cout << COLOR_VIOLET << "Word chosen." << COLOR_RESET << "\n";
    }

    else if (cmd == "check_guess") {
    if (argc < 3) {
        std::cerr << "Please specify a letter to guess\n";
        return 1;
    }
    if (!game.loadGameState(stateFile)) {
        std::cerr << "No saved game found\n";
        return 1;
    }
    char letter = argv[2][0];
    bool correct = game.guessLetter(letter);
    game.saveGameState(stateFile);

    if (correct)
        std::cout << COLOR_GREEN << "Correct" << COLOR_RESET << "\n";
    else
        std::cout << COLOR_RED << "Wrong" << COLOR_RESET << "\n";

    if (game.isWin()) {
        std::cout << COLOR_GREEN << "You won! The word was: " << game.word.actualWord << COLOR_RESET << "\n";
    }
    else if (game.isGameOver()) {
        std::cout << COLOR_RED << "Game over! The word was: " << game.word.actualWord << COLOR_RESET << "\n";
    }
    }
    return 0;
}
